package week2_class_20221995;

public class chapter1_2 {
	
	public static void main(String[] args) {

		System.out.println("20221995");
		System.out.println("신민재");
	}
	
}
